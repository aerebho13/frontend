
import "./cart.css";


const Cart = () => {
    return (
        <div className="cart-page">
        <h1>This is the cart</h1>

        </div>
    );
};

export default Cart;